from django.contrib import admin
from .models import Post, picture


admin.site.register(Post)
admin.site.register(picture)


# Register your models here.
