from django.apps import AppConfig


class LebaraConfig(AppConfig):
    name = 'lebara'
