from django.db import models
from django.utils import timezone
from django.urls import reverse
from django.contrib.auth.models import User


class Post(models.Model):
    Incident_name = models.CharField(max_length=200)
    Update = models.TextField()
    Incident_Starttime = models.DateTimeField(default=timezone.now)
    Incident_Endtime = models.DateTimeField(default=timezone.now)
    Country_impacted = models.CharField(max_length=300)
    Services_impacted = models.CharField(max_length=240)
    Resolution_Summary = models.TextField(null=True, blank=True)
    Summary_of_the_Impact = models.TextField(null=True, blank=True)
    date_posted = models.DateTimeField(default=timezone.now)
    next_update_time = models.DateTimeField(default=timezone.now)



    def __str__(self):
        return self.Incident_name

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})


class picture(models.Model):
    image = models.ImageField(default='default.jpg')