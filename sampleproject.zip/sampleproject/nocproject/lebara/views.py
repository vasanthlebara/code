from django.shortcuts import render,redirect
from django.views.generic import(
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView

)
from .models import Post, picture
from django.urls import reverse
from django.core.mail import send_mail
from django.template.loader import render_to_string


def open(request):
    context ={
        'post':Post.objects.all()
    }
    return render(request, 'lebara/open.html',context)


class PostListView(ListView):
    model = Post
    template_name ='lebara/open.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']

class PostDetailView(DetailView):
    model = Post

class PostCreateView(CreateView):
    model = Post
    fields = ['Incident_name','Incident_Starttime', 'Country_impacted', 'Services_impacted','Summary_of_the_Impact','Update','next_update_time']

class PostUpdateView(UpdateView):
    model = Post
    fields = ['Incident_name','Incident_Starttime', 'Country_impacted', 'Services_impacted','Summary_of_the_Impact','Update','next_update_time']

class PostDeleteView(DeleteView):
    model = Post
    success_url ='/'



def incidents(request):
    return render(request, 'lebara/incidents.html')

def home(request):

    context1 = {

        'pic': picture.objects.all()
    }
    return render(request,'lebara/home.html', context1)



class emailview(DetailView):
    model = Post

    def send_email(request):
        context = {
            'post': Post.objects.all()
        }
        if request.method == 'POST':
            email = request.POST.get("email")
            html_message = render_to_string('lebara/post_detail_email.html', context)
            send_mail('Testmail',html_message,'vasanthlebara@gmail.com',[email],fail_silently=True)
            return redirect('lebara-open')
        else:
            return render(request, 'lebara/post_detail_email.html', context)

