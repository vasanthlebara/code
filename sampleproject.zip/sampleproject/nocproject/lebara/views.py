from django.shortcuts import render
from django.views.generic import(
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView

)
from .models import Post, picture
from django.urls import reverse

def open(request):
    context ={
        'post':Post.objects.all()
    }
    return render(request, 'lebara/open.html',context)


class PostListView(ListView):
    model = Post
    template_name ='lebara/open.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']

class PostDetailView(DetailView):
    model = Post

class PostCreateView(CreateView):
    model = Post
    fields = ['Incident_name','Incident_Starttime', 'Country_impacted', 'Services_impacted','Summary_of_the_Impact','Update','next_update_time']

class PostUpdateView(UpdateView):
    model = Post
    fields = ['Incident_name','Incident_Starttime', 'Country_impacted', 'Services_impacted','Summary_of_the_Impact','Update','next_update_time']

class PostDeleteView(DeleteView):
    model = Post
    success_url ='/'



def incidents(request):
    return render(request, 'lebara/incidents.html')

def home(request):

    context1 = {

        'pic': picture.objects.all()
    }
    return render(request,'lebara/home.html', context1)
